#!/bin/bash
sudo apt-get update && sudo apt-get upgrade -y
sudo apt install openjdk-11-jre-headless -y
